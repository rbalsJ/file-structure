//testind.cc - TextindexedFile ��� �ǽ�
#include "textind.h"
#include "delim.h"
#include "buffile.h"
#include "recordng.h"
#include "indfile.h"
#include <iostream>

//ä�� �� ��ó���⿡ _CRT_SECURE_NO_WARNINGS;_CRT_NONSTDC_NO_DEPRECATE; �߰� ��Ź�帳�ϴ�.

int main (void)
{// first argument is the file name for the data file
	int result;

	TextIndex RecIndex (10);
	DelimFieldBuffer Buffer; // create a buffer
	TextIndexedFile<Recording> IndFile (Buffer, 12, 10);
	//TextIndexedFile<RecType>::TextIndexedFile(IOBuffer & buffer, int keySize, int maxKeys)
	char filename[20];
	cout << "Enter index file's name : ";
	cin >> filename;

	result = IndFile . Create (filename, ios::out);
	if (!result) 
	{
		cout<<"Unable to open indfile "<<result<<endl;
		return 0;
	}	
	int recaddr;
	//write records
	Recording* R[10], foundRecord;

	R[0] = new Recording("Kwon", "201724410", "Busan", "2022-03-01", "20");
	R[1] = new Recording("Kim", "201724411", "Seoul", "2022-03-02", "23");
	R[2] = new Recording("Hong", "201724412", "Jeju", "2022-03-03", "18");
	R[3] = new Recording("Lee", "201724413", "Ulsan", "2021-03-01", "20");
	R[4] = new Recording("Choi", "201724414", "Daegu", "2020-03-01", "17");
	R[5] = new Recording("Park", "201724415", "Incheon", "2019-03-01", "15");
	R[6] = new Recording("Jeong", "201724416", "Busan", "2018-03-01", "12");
	R[7] = new Recording("Jang", "201724417", "Gwangju", "2022-02-28", "20");
	R[8] = new Recording("Yang", "201724418", "Ulsan", "2022-02-27", "22");
	R[9] = new Recording("Song", "201724419", "Gimhae", "2022-02-26", "20");
	for (int i = 0; i < 10; i++)
	{
		recaddr = IndFile.Append(*R[i]);
		cout << "IndFile R[" << i << "] at recaddr " << recaddr << endl;
	}

	char searchKey[20];
	cout << "Enter key to find data : ";
	cin >> searchKey;
	//char* searchKey = "DG139201";
	IndFile.Read(searchKey, foundRecord);
	foundRecord.Print(cout);
	IndFile.Close();
	system("pause");
	return 1;
}

