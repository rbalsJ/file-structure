//Recording.cpp
#include "recordng.h"
#include <strstream>
#include <string.h>

Recording::Recording ()
{
	Name[0] = 0;
	StudentID[0] = 0;
	Address[0] = 0;
	Date[0] = 0;
	Credit[0] = 0;
}

Recording::Recording (const char* name, const char* studentID, const char* address,
	const char* date, const char* credit)
{
	strcpy(Name, name); strcpy(StudentID, studentID);
	strcpy(Address, address); strcpy(Date, date);
	strcpy(Credit, credit);
}

char * Recording::Key () const
{// produce key as concatenation of Label and IdNum
	ostrstream key;
	key << Name << StudentID << ends;
	return key.str();	
}

int Recording::Pack (IOBuffer & Buffer) const
{// return TRUE if all succeed, FALSE o/w
	int numBytes;
	Buffer . Clear ();
	numBytes = Buffer . Pack (Name);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (StudentID);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (Address);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (Date);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (Credit);
	if (numBytes == -1) return FALSE;
	return TRUE;
}

int Recording::Unpack (IOBuffer & Buffer)
{// unpack with maximum size, and add null termination to strings
	int numBytes;
	numBytes = Buffer . Unpack (Name, 29);
	if (numBytes == -1) return FALSE;
	Name[numBytes] = 0;
	numBytes = Buffer . Unpack (StudentID, 14);
	if (numBytes == -1) return FALSE;
	StudentID[numBytes] = 0;
	numBytes = Buffer . Unpack (Address, 29);
	if (numBytes == -1) return FALSE;
	Address[numBytes] = 0;
	numBytes = Buffer . Unpack (Date, 29);
	if (numBytes == -1) return FALSE;
	Date[numBytes] = 0;
	numBytes = Buffer . Unpack (Credit, 6);
	if (numBytes == -1) return FALSE;
	Credit[numBytes] = 0;
	return TRUE;
}

void Recording::Print (ostream & stream, char * label) const
{
	stream << Name <<'|'<< StudentID <<'|' << Address <<'|'
		<< Date <<'|'<< Credit << endl;
}
int Recording::InitBuffer(FixedFieldBuffer& Buffer)
// initialize a FixedFieldBuffer to be used for Persons
{
	int result;
	result = Buffer.AddField(30); // IdNum[7]
	result = result && Buffer.AddField(15); // Title[30]
	result = result && Buffer.AddField(30); // Composer[30]
	result = result && Buffer.AddField(30); // Artist[30]
	result = result && Buffer.AddField(7); // Label[7]
	return result;
}
//char IdNum[7]; char Title[30]; char Composer[30];char Artist[30]; char Label[7];
int Recording::InitBuffer(DelimFieldBuffer& Buffer)
// initialize a DelimFieldBuffer to be used for Persons
{
	return TRUE;
}

int Recording::InitBuffer(LengthFieldBuffer& Buffer)
// initialize a LengthFieldBuffer to be used for Persons
{
	return TRUE;
}
